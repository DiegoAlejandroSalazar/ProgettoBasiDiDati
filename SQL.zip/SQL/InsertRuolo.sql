INSERT INTO `Farmaciadb`.`Ruolo` (`NomeQualifica`) VALUES ('Farmacista');
INSERT INTO `Farmaciadb`.`Ruolo` (`NomeQualifica`) VALUES ('Collaboratore Farmacista');
INSERT INTO `Farmaciadb`.`Ruolo` (`NomeQualifica`) VALUES ('Magazziniere');
INSERT INTO `Farmaciadb`.`Ruolo` (`NomeQualifica`) VALUES ('Direttore');
