INSERT INTO `Farmaciadb`.`Cassa` (`IdCassa`, `ContanteDisponibile`) VALUES (1, 1000.50);
INSERT INTO `Farmaciadb`.`Cassa` (`IdCassa`, `ContanteDisponibile`) VALUES (2, 2000.75);
INSERT INTO `Farmaciadb`.`Cassa` (`IdCassa`, `ContanteDisponibile`) VALUES (3, 1500.00);
INSERT INTO `Farmaciadb`.`Cassa` (`IdCassa`, `ContanteDisponibile`) VALUES (4, 1750.25);
INSERT INTO `Farmaciadb`.`Cassa` (`IdCassa`, `ContanteDisponibile`) VALUES (5, 2250.80);
